from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from fastapi.templating import Jinja2Templates

from app.database import Base, SessionLocal, engine
from app.models import Video
from app.routers import videos

SEED_VIDEOS = [
    {
        "title": "Apple Bipbop (multi-bitrate)",
        "m3u8_url": "https://devstreaming-cdn.apple.com/videos/streaming/examples/bipbop_16x9/bipbop_16x9_variant.m3u8",
    },
    {
        "title": "Big Buck Bunny",
        "m3u8_url": "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
    },
    {
        "title": "Sintel",
        "m3u8_url": "https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8",
    },
    {
        "title": "IfBest Demo Stream",
        "m3u8_url": "/static/master.m3u8",
    },
]


def seed_database():
    db = SessionLocal()
    try:
        if db.query(Video).count() == 0:
            print("Заполнение базы данных тестовыми видео...")
            for item in SEED_VIDEOS:
                video = Video(
                    title=item["title"],
                    m3u8_url=item["m3u8_url"],
                    views=0
                )
                db.add(video)
            db.commit()
            print(f"Добавлено {len(SEED_VIDEOS)} видео")
        else:
            print(f"В базе уже есть {db.query(Video).count()} видео")
    except Exception as e:
        print(f"Ошибка при заполнении БД: {e}")
        db.rollback()
    finally:
        db.close()


@asynccontextmanager
async def lifespan(app: FastAPI):
    print("Запуск приложения...")
    Base.metadata.create_all(bind=engine)
    seed_database()
    yield
    print("Завершение приложения...")


app = FastAPI(
    title="IfBest Video Player API",
    description="API для видеоплеера с поддержкой HLS",
    version="1.0.0",
    lifespan=lifespan
)

app.mount("/static", StaticFiles(directory="app/static"), name="static")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

templates = Jinja2Templates(directory=Path(__file__).parent / "app" / "templates")

app.include_router(videos.router)

@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request):
    return templates.TemplateResponse(
        "index.html",
        {
            "request": request,
            "page_title": "Видеоплеер IfBest"
        }
    )


@app.get("/player/{video_id}", response_class=HTMLResponse)
async def read_player(request: Request, video_id: int):
    return templates.TemplateResponse(
        "player.html",
        {
            "request": request,
            "video_id": video_id,
            "page_title": "Воспроизведение"
        }
    )

@app.get("/health")
async def health_check():
    return {
        "status": "ok",
        "message": "IfBest Video Player API работает",
        "version": "1.0.0"
    }

if __name__ == "__main__":
    import uvicorn
    
    print("=" * 50)
    print("Запуск IfBest Video Player API...")
    print("=" * 50)
    print("Откройте в браузере: http://127.0.0.1:8000")
    print("Документация API: http://127.0.0.1:8000/docs")
    print("=" * 50)
    
    uvicorn.run(
        "main:app",
        host="127.0.0.1",
        port=8000,
        reload=True
    )