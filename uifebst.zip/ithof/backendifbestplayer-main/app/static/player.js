class VideoPlayer {
    constructor() {
        this.video = null;
        this.hls = null;
        this.videoId = null;
        this.videoData = null;
        this.levels = [];
        this.currentLevel = -1;
        this.viewRecorded = false;
        
        this.init();
    }

    async init() {
        const pathParts = window.location.pathname.split('/');
        this.videoId = parseInt(pathParts[pathParts.length - 1]);
        
        if (!this.videoId || isNaN(this.videoId)) {
            this.showError('Неверный ID видео');
            return;
        }

        await this.loadVideoData();
        this.initElements();
        this.setupPlayer();
        this.setupControls();
    }

    async loadVideoData() {
        try {
            const response = await fetch('/api/videos');
            const videos = await response.json();
            
            this.videoData = videos.find(v => v.id === this.videoId);
            
            if (!this.videoData) {
                throw new Error('Video not found');
            }
            document.getElementById('video-title').textContent = this.videoData.title;
            document.title = `${this.videoData.title} — IfBest`;
            document.getElementById('views-count').textContent = this.videoData.views;
            
        } catch (error) {
            console.error('Error loading video data:', error);
            this.showError('Не удалось загрузить видео');
        }
    }

    initElements() {
        this.video = document.getElementById('video-wrapper');
        this.videoElement = document.getElementById('video-player');
        this.playPauseBtn = document.getElementById('play-pause-btn');
        this.playIcon = document.getElementById('play-icon');
        this.pauseIcon = document.getElementById('pause-icon');
        this.bigPlayBtn = document.getElementById('big-play-btn');
        this.progressContainer = document.getElementById('progress-container');
        this.progressFilled = document.getElementById('progress-filled');
        this.currentTimeEl = document.getElementById('current-time');
        this.durationEl = document.getElementById('duration');
        this.fullscreenBtn = document.getElementById('fullscreen-btn');
        this.fullscreenIcon = document.getElementById('fullscreen-icon');
        this.exitFullscreenIcon = document.getElementById('exit-fullscreen-icon');
        this.speedBtn = document.getElementById('speed-btn');
        this.speedValue = document.getElementById('speed-value');
        this.speedMenu = document.getElementById('speed-menu');
        this.qualityBtn = document.getElementById('quality-btn');
        this.qualityText = document.getElementById('quality-text');
        this.qualityMenu = document.getElementById('quality-menu');
        this.qualityDropdown = document.getElementById('quality-dropdown');
        this.qualityBadge = document.getElementById('quality-badge');
    }

    setupPlayer() {
        const videoUrl = this.videoData.m3u8_url;

        if (Hls.isSupported()) {
            this.hls = new Hls({
                enableWorker: true,
                lowLatencyMode: false
            });

            this.hls.loadSource(videoUrl);
            this.hls.attachMedia(this.videoElement);

            this.hls.on(Hls.Events.MANIFEST_PARSED, (event, data) => {
                console.log('Manifest loaded, found levels:', data.levels.length);
                this.levels = data.levels;
                this.setupQualityMenu();
            });

            this.hls.on(Hls.Events.LEVEL_SWITCHED, (event, data) => {
                this.updateQualityBadge();
            });

            this.hls.on(Hls.Events.ERROR, (event, data) => {
                console.error('HLS Error:', data);
                if (data.fatal) {
                    switch (data.type) {
                        case Hls.ErrorTypes.NETWORK_ERROR:
                            console.error('Fatal network error, trying to recover...');
                            this.hls.startLoad();
                            break;
                        case Hls.ErrorTypes.MEDIA_ERROR:
                            console.error('Fatal media error, trying to recover...');
                            this.hls.recoverMediaError();
                            break;
                        default:
                            console.error('Fatal error, destroying player...');
                            this.hls.destroy();
                            break;
                    }
                }
            });

        } else if (this.videoElement.canPlayType('application/vnd.apple.mpegurl')) {
            this.videoElement.src = videoUrl;
        }

        this.videoElement.addEventListener('loadedmetadata', () => {
            this.durationEl.textContent = this.formatTime(this.videoElement.duration);
        });

        this.videoElement.addEventListener('timeupdate', () => {
            this.updateProgress();
        });

        this.videoElement.addEventListener('play', () => {
            this.onPlay();
        });

        this.videoElement.addEventListener('pause', () => {
            this.onPause();
        });

        this.videoElement.addEventListener('ended', () => {
            this.onEnded();
        });

        this.video.addEventListener('mouseenter', () => {
            document.getElementById('player-controls').classList.add('visible');
        });

        this.video.addEventListener('mouseleave', () => {
            if (this.videoElement.paused) return;
            document.getElementById('player-controls').classList.remove('visible');
        });
    }

    setupControls() {
        this.playPauseBtn.addEventListener('click', () => this.togglePlay());
        this.bigPlayBtn.addEventListener('click', () => this.togglePlay());
        
        this.progressContainer.addEventListener('click', (e) => this.seek(e));
        
        this.fullscreenBtn.addEventListener('click', () => this.toggleFullscreen());
        
        this.speedMenu.querySelectorAll('.dropdown-item').forEach(item => {
            item.addEventListener('click', () => {
                const speed = parseFloat(item.dataset.speed);
                this.setSpeed(speed);
            });
        });

        document.addEventListener('keydown', (e) => {
            switch(e.key) {
                case ' ':
                    e.preventDefault();
                    this.togglePlay();
                    break;
                case 'ArrowLeft':
                    this.seekRelative(-10);
                    break;
                case 'ArrowRight':
                    this.seekRelative(10);
                    break;
                case 'ArrowUp':
                    this.adjustVolume(0.1);
                    break;
                case 'ArrowDown':
                    this.adjustVolume(-0.1);
                    break;
                case 'f':
                    this.toggleFullscreen();
                    break;
                case 'm':
                    this.toggleMute();
                    break;
            }
        });
    }

    togglePlay() {
        if (this.videoElement.paused) {
            this.videoElement.play();
        } else {
            this.videoElement.pause();
        }
    }

    async onPlay() {
        this.video.classList.add('playing');
        this.video.classList.remove('paused');
        this.playIcon.style.display = 'none';
        this.pauseIcon.style.display = 'block';
        
        if (!this.viewRecorded) {
            await this.incrementViewCount();
            this.viewRecorded = true;
        }
    }

    onPause() {
        this.video.classList.add('paused');
        this.video.classList.remove('playing');
        this.playIcon.style.display = 'block';
        this.pauseIcon.style.display = 'none';
    }

    onEnded() {
        this.video.classList.add('paused');
        this.video.classList.remove('playing');
        this.playIcon.style.display = 'block';
        this.pauseIcon.style.display = 'none';
        this.videoElement.currentTime = 0;
        this.progressFilled.style.width = '0%';
    }

    async incrementViewCount() {
        try {
            const response = await fetch(`/api/videos/${this.videoId}/view`, {
                method: 'POST'
            });
            
            if (response.ok) {
                const data = await response.json();
                document.getElementById('views-count').textContent = data.views;
            }
        } catch (error) {
            console.error('Error incrementing view count:', error);
        }
    }

    updateProgress() {
        const current = this.videoElement.currentTime;
        const duration = this.videoElement.duration;
        
        if (duration) {
            const percent = (current / duration) * 100;
            this.progressFilled.style.width = `${percent}%`;
            this.currentTimeEl.textContent = this.formatTime(current);
        }
    }

    seek(e) {
        const rect = this.progressContainer.getBoundingClientRect();
        const pos = (e.clientX - rect.left) / rect.width;
        this.videoElement.currentTime = pos * this.videoElement.duration;
    }

    seekRelative(seconds) {
        this.videoElement.currentTime = Math.max(0, 
            Math.min(this.videoElement.duration, 
            this.videoElement.currentTime + seconds));
    }

    adjustVolume(delta) {
        this.videoElement.volume = Math.max(0, Math.min(1, 
            this.videoElement.volume + delta));
    }

    toggleMute() {
        this.videoElement.muted = !this.videoElement.muted;
    }

    toggleFullscreen() {
        const wrapper = document.getElementById('video-wrapper');
        
        if (!document.fullscreenElement) {
            wrapper.requestFullscreen().then(() => {
                this.fullscreenIcon.style.display = 'none';
                this.exitFullscreenIcon.style.display = 'block';
            }).catch(err => {
                console.error('Error attempting to enable fullscreen:', err);
            });
        } else {
            document.exitFullscreen().then(() => {
                this.fullscreenIcon.style.display = 'block';
                this.exitFullscreenIcon.style.display = 'none';
            });
        }
    }

    setSpeed(speed) {
        this.videoElement.playbackRate = speed;
        this.speedValue.textContent = `${speed}x`;
        
        this.speedMenu.querySelectorAll('.dropdown-item').forEach(item => {
            item.classList.toggle('selected', parseFloat(item.dataset.speed) === speed);
        });
    }

    setupQualityMenu() {
        if (this.levels.length <= 1) {
            this.qualityDropdown.style.display = 'none';
            return;
        }

        this.qualityDropdown.style.display = 'block';
        
        let menuHtml = `
            <button class="dropdown-item ${this.currentLevel === -1 ? 'selected' : ''}" data-level="-1">
                Auto
            </button>
        `;

        this.levels.forEach((level, index) => {
            const quality = level.height || Math.round(level.bitrate / 1000);
            const label = `${quality}p`;
            menuHtml += `
                <button class="dropdown-item ${this.currentLevel === index ? 'selected' : ''}" data-level="${index}">
                    ${label}
                </button>
            `;
        });

        this.qualityMenu.innerHTML = menuHtml;

        this.qualityMenu.querySelectorAll('.dropdown-item').forEach(item => {
            item.addEventListener('click', () => {
                const level = parseInt(item.dataset.level);
                this.setQuality(level);
            });
        });
    }

    setQuality(level) {
        this.currentLevel = level;
        
        if (this.hls) {
            this.hls.currentLevel = level;
        }

        this.qualityMenu.querySelectorAll('.dropdown-item').forEach(item => {
            item.classList.toggle('selected', parseInt(item.dataset.level) === level);
        });

        if (level === -1) {
            this.qualityText.textContent = 'Auto';
        } else {
            const levelData = this.levels[level];
            const quality = levelData.height || Math.round(levelData.bitrate / 1000);
            this.qualityText.textContent = `${quality}p`;
        }

        this.updateQualityBadge();
    }

    updateQualityBadge() {
        if (!this.levels.length) return;

        if (this.currentLevel === -1) {
            this.qualityBadge.style.display = 'block';
            this.qualityBadge.textContent = 'Auto';
        } else {
            const levelData = this.levels[this.currentLevel];
            const quality = levelData.height || Math.round(levelData.bitrate / 1000);
            this.qualityBadge.style.display = 'block';
            this.qualityBadge.textContent = `${quality}p`;
        }
    }

    formatTime(seconds) {
        if (isNaN(seconds)) return '0:00';
        
        const mins = Math.floor(seconds / 60);
        const secs = Math.floor(seconds % 60);
        return `${mins}:${secs.toString().padStart(2, '0')}`;
    }

    showError(message) {
        document.getElementById('video-title').textContent = message;
        document.querySelector('.video-info').style.display = 'none';
    }
}

document.addEventListener('DOMContentLoaded', () => {
    new VideoPlayer();
});