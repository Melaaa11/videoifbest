# backendifbestplayer

Backend API для видеоплеера IfBest (FastAPI + SQLite).

## Запуск

```bash
pip install -r requirements.txt
uvicorn app.main:app --reload
```

API: http://127.0.0.1:8000/docs

## Эндпоинты

| Метод | URL | Описание |
|-------|-----|----------|
| GET | `/api/videos` | Список видео |
| POST | `/api/videos/{id}/view` | +1 просмотр → `{"views": N}` |

При первом запуске создаётся `videos.db` с тестовыми HLS-видео.
