from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware

from app.database import Base, SessionLocal, engine
from app.models import Video
from app.routers import videos

SEED_VIDEOS = [
    {
        "title": "Apple Bipbop (multi-bitrate)",
        "m3u8_url": "https://devstreaming-cdn.apple.com/videos/streaming/examples/bipbop_16x9/bipbop_16x9_variant.m3u8",
    },
    {
        "title": "Big Buck Bunny",
        "m3u8_url": "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
    },
    {
        "title": "Sintel",
        "m3u8_url": "https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8",
    },
]


def seed_database():
    db = SessionLocal()
    try:
        if db.query(Video).count() == 0:
            for item in SEED_VIDEOS:
                db.add(Video(title=item["title"], m3u8_url=item["m3u8_url"], views=0))
            db.commit()
    finally:
        db.close()


@asynccontextmanager
async def lifespan(_: FastAPI):
    Base.metadata.create_all(bind=engine)
    seed_database()
    yield


app = FastAPI(title="IfBest Video Player API", lifespan=lifespan)

app.mount("/static", StaticFiles(directory="app/static"), name="static")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(videos.router)
