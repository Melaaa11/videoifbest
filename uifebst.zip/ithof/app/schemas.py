from pydantic import BaseModel, ConfigDict


class VideoRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    title: str
    m3u8_url: str
    views: int


class ViewCountResponse(BaseModel):
    views: int
