from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import Video
from app.schemas import VideoRead, ViewCountResponse

router = APIRouter(prefix="/api/videos", tags=["videos"])


@router.get("", response_model=list[VideoRead])
def list_videos(db: Session = Depends(get_db)):
    return db.query(Video).order_by(Video.id).all()


@router.post("/{video_id}/view", response_model=ViewCountResponse)
def increment_view(video_id: int, db: Session = Depends(get_db)):
    video = db.query(Video).filter(Video.id == video_id).first()
    if video is None:
        raise HTTPException(status_code=404, detail="Video not found")

    video.views += 1
    db.commit()
    db.refresh(video)
    return ViewCountResponse(views=video.views)
