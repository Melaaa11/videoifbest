const API_BASE = '';

class VideoApp {
    constructor() {
        this.videos = [];
        this.init();
    }

    async init() {
        await this.loadVideos();
    }

    async loadVideos() {
        try {
            const response = await fetch('/api/videos');
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            this.videos = await response.json();
            this.renderVideos();
            
        } catch (error) {
            console.error('Error loading videos:', error);
            this.showError('Не удалось загрузить видео. Проверьте подключение к серверу.');
        }
    }

    renderVideos() {
        const container = document.getElementById('video-list');
        
        if (!this.videos || this.videos.length === 0) {
            container.innerHTML = '<div class="error-message">Нет доступных видео</div>';
            return;
        }

        container.innerHTML = this.videos.map(video => this.createVideoCard(video)).join('');

        container.querySelectorAll('.video-card').forEach(card => {
            card.addEventListener('click', () => {
                const videoId = parseInt(card.dataset.id);
                this.openPlayer(videoId);
            });
        });
    }

    createVideoCard(video) {
        const formattedViews = this.formatViews(video.views);
        
        return `
            <article class="video-card" data-id="${video.id}" data-url="${video.m3u8_url}">
                <div class="video-card-thumbnail">
                    <div class="play-icon">▶</div>
                </div>
                <div class="video-card-info">
                    <h3 class="video-card-title">${this.escapeHtml(video.title)}</h3>
                    <div class="video-card-meta">
                        <span class="view-count">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                                <circle cx="12" cy="12" r="3"></circle>
                            </svg>
                            ${formattedViews}
                        </span>
                    </div>
                </div>
            </article>
        `;
    }

    openPlayer(videoId) {
        window.location.href = `/player/${videoId}`;
    }

    formatViews(views) {
        if (views >= 1000000) {
            return (views / 1000000).toFixed(1) + 'M';
        } else if (views >= 1000) {
            return (views / 1000).toFixed(1) + 'K';
        }
        return views.toString();
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    showError(message) {
        const container = document.getElementById('video-list');
        container.innerHTML = `<div class="error-message">${message}</div>`;
    }
}

document.addEventListener('DOMContentLoaded', () => {
    new VideoApp();
});